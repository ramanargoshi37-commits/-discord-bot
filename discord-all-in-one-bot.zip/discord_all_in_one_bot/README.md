# Discord All-in-One Bot

Node.js 20 + Discord.js v14 starter with moderation, tickets, welcome/auto-role, basic AutoMod, economy, info, and hooks for AI/music.

## Setup
1. Copy `.env.example` to `.env`
2. Set `DISCORD_TOKEN`, `CLIENT_ID`, and `GUILD_ID`
3. Enable Server Members Intent and Message Content Intent in the Discord Developer Portal.
4. Run `npm install`
5. Run `npm start`

Never share your bot token or `.env` file.

Slash commands are registered to the server in `GUILD_ID` for fast updates.
