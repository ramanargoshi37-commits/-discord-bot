require("dotenv").config();
const {Client, Collection, GatewayIntentBits, Partials} = require("discord.js");
const fs = require("fs");
const path = require("path");

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildVoiceStates
  ],
  partials: [Partials.Channel, Partials.Message, Partials.GuildMember]
});

client.commands = new Collection();
for (const file of fs.readdirSync(path.join(__dirname, "commands")).filter(f => f.endsWith(".js"))) {
  const command = require(path.join(__dirname, "commands", file));
  client.commands.set(command.data.name, command);
}
for (const file of fs.readdirSync(path.join(__dirname, "events")).filter(f => f.endsWith(".js"))) {
  require(path.join(__dirname, "events", file))(client);
}

client.once("ready", async () => {
  console.log(`Logged in as ${client.user.tag}`);
  if (!process.env.GUILD_ID) return console.warn("GUILD_ID is missing.");
  const guild = await client.guilds.fetch(process.env.GUILD_ID).catch(() => null);
  if (!guild) return console.warn("GUILD_ID not found or bot is not in that server.");
  await guild.commands.set([...client.commands.values()].map(c => c.data.toJSON()));
  console.log(`Registered ${client.commands.size} commands in ${guild.name}.`);
});

client.on("interactionCreate", async interaction => {
  try {
    if (interaction.isButton()) {
      const tickets = require("./services/tickets");
      if (interaction.customId === "ticket_create") return tickets.create(interaction);
      if (interaction.customId === "ticket_close") return tickets.close(interaction);
    }
    if (!interaction.isChatInputCommand()) return;
    const command = client.commands.get(interaction.commandName);
    if (command) await command.execute(interaction);
  } catch (e) {
    console.error(e);
    const reply = {content: "❌ An error occurred.", ephemeral: true};
    if (interaction.replied || interaction.deferred) await interaction.followUp(reply).catch(() => {});
    else await interaction.reply(reply).catch(() => {});
  }
});

client.login(process.env.DISCORD_TOKEN);
