const {ChannelType,PermissionFlagsBits,ActionRowBuilder,ButtonBuilder,ButtonStyle}=require("discord.js");
async function create(i){const old=i.guild.channels.cache.find(c=>c.type===ChannelType.GuildText&&c.name===`ticket-${i.user.id}`);if(old)return i.reply({content:`You already have ${old}`,ephemeral:true});
 const ch=await i.guild.channels.create({name:`ticket-${i.user.id}`,type:ChannelType.GuildText,permissionOverwrites:[{id:i.guild.id,deny:[PermissionFlagsBits.ViewChannel]},{id:i.user.id,allow:[PermissionFlagsBits.ViewChannel,PermissionFlagsBits.SendMessages,PermissionFlagsBits.ReadMessageHistory]}]});
 const row=new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId("ticket_close").setLabel("Close Ticket").setEmoji("🔒").setStyle(ButtonStyle.Danger));
 await ch.send({content:`🎫 Welcome ${i.user}! Describe your issue here.`,components:[row]});await i.reply({content:`✅ Ticket created: ${ch}`,ephemeral:true});}
async function close(i){if(!i.channel.name.startsWith("ticket-"))return i.reply({content:"❌ Not a ticket.",ephemeral:true});await i.reply("🔒 Closing ticket...");setTimeout(()=>i.channel.delete().catch(()=>{}),1200);}
module.exports={create,close};