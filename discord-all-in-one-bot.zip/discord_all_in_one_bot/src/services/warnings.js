const fs=require("fs"),path=require("path");const file=path.join(__dirname,"../../data/warnings.json");
function read(){if(!fs.existsSync(file))fs.writeFileSync(file,"{}");return JSON.parse(fs.readFileSync(file,"utf8"))}
function add(g,u,r){const d=read();d[g]??={};d[g][u]??=[];d[g][u].push({reason:r,at:new Date().toISOString()});fs.writeFileSync(file,JSON.stringify(d,null,2));return d[g][u].length}
module.exports={add};