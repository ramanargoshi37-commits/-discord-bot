const fs=require("fs"),path=require("path");const file=path.join(__dirname,"../../data/economy.json");
function read(){if(!fs.existsSync(file))fs.writeFileSync(file,"{}");return JSON.parse(fs.readFileSync(file,"utf8"))}
function save(d){fs.writeFileSync(file,JSON.stringify(d,null,2))}
function get(g,u){const d=read();d[g]??={};d[g][u]??={coins:0,lastDaily:0};save(d);return d[g][u]}
function daily(g,u){const d=read();d[g]??={};d[g][u]??={coins:0,lastDaily:0};const a=d[g][u],now=Date.now();if(now-a.lastDaily<86400000)return{ok:false,remaining:86400000-(now-a.lastDaily),account:a};a.coins+=250;a.lastDaily=now;save(d);return{ok:true,account:a}}
module.exports={get,daily};