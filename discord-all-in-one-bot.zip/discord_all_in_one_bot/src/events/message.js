const {Events} = require("discord.js");
const blocked = ["discord.gg/", "free nitro", "mass dm"];
module.exports = client => client.on(Events.MessageCreate, async message => {
  if (message.author.bot || !message.guild) return;
  if (blocked.some(x => message.content.toLowerCase().includes(x))) {
    await message.delete().catch(() => {});
    const m = await message.channel.send(`⚠️ ${message.author}, your message was removed by AutoMod.`).catch(() => null);
    if (m) setTimeout(() => m.delete().catch(() => {}), 5000);
  }
});
