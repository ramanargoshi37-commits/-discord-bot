const {Events} = require("discord.js");
module.exports = client => client.on(Events.GuildMemberAdd, async member => {
  if (process.env.AUTO_ROLE_ID) {
    const role = member.guild.roles.cache.get(process.env.AUTO_ROLE_ID);
    if (role) await member.roles.add(role).catch(() => {});
  }
  if (process.env.WELCOME_CHANNEL_ID) {
    const ch = member.guild.channels.cache.get(process.env.WELCOME_CHANNEL_ID);
    if (ch?.isTextBased()) await ch.send(`👋 Welcome ${member} to **${member.guild.name}**!`).catch(() => {});
  }
});
