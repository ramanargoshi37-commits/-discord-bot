const {SlashCommandBuilder}=require("discord.js"),ai=require("../services/ai");
module.exports={data:new SlashCommandBuilder().setName("ai").setDescription("Ask AI").addStringOption(o=>o.setName("prompt").setDescription("Question").setRequired(true)),
async execute(i){await i.deferReply();await i.editReply(await ai.ask(i.options.getString("prompt")))}};