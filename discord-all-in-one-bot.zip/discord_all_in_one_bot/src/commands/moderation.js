const {SlashCommandBuilder, PermissionFlagsBits} = require("discord.js");
const warnings = require("../services/warnings");
module.exports = {
 data:new SlashCommandBuilder().setName("moderation").setDescription("Moderation")
 .addSubcommand(s=>s.setName("ban").setDescription("Ban").addUserOption(o=>o.setName("user").setDescription("User").setRequired(true)).addStringOption(o=>o.setName("reason").setDescription("Reason")))
 .addSubcommand(s=>s.setName("kick").setDescription("Kick").addUserOption(o=>o.setName("user").setDescription("User").setRequired(true)).addStringOption(o=>o.setName("reason").setDescription("Reason")))
 .addSubcommand(s=>s.setName("timeout").setDescription("Timeout").addUserOption(o=>o.setName("user").setDescription("User").setRequired(true)).addIntegerOption(o=>o.setName("minutes").setDescription("Minutes").setRequired(true).setMinValue(1).setMaxValue(40320)).addStringOption(o=>o.setName("reason").setDescription("Reason")))
 .addSubcommand(s=>s.setName("warn").setDescription("Warn").addUserOption(o=>o.setName("user").setDescription("User").setRequired(true)).addStringOption(o=>o.setName("reason").setDescription("Reason").setRequired(true)))
 .addSubcommand(s=>s.setName("clear").setDescription("Delete messages").addIntegerOption(o=>o.setName("amount").setDescription("1-100").setRequired(true).setMinValue(1).setMaxValue(100)))
 .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),
 async execute(i) {
  const sub=i.options.getSubcommand();
  if(sub==="clear"){if(!i.member.permissions.has(PermissionFlagsBits.ManageMessages))return i.reply({content:"❌ Manage Messages required.",ephemeral:true});const n=i.options.getInteger("amount");const d=await i.channel.bulkDelete(n,true);return i.reply({content:`🧹 Deleted ${d.size} messages.`,ephemeral:true});}
  const u=i.options.getUser("user"), m=await i.guild.members.fetch(u.id).catch(()=>null), r=i.options.getString("reason")||"No reason";
  if(!m)return i.reply({content:"❌ Member not found.",ephemeral:true});
  if(sub==="ban"){await m.ban({reason:r});return i.reply(`🔨 Banned **${u.tag}** — ${r}`);}
  if(sub==="kick"){await m.kick(r);return i.reply(`👢 Kicked **${u.tag}** — ${r}`);}
  if(sub==="timeout"){const min=i.options.getInteger("minutes");await m.timeout(min*60000,r);return i.reply(`⏳ Timed out **${u.tag}** for ${min} minutes.`);}
  const count=warnings.add(i.guild.id,u.id,r);return i.reply(`⚠️ Warned **${u.tag}**. Total warnings: **${count}**.`);
 }
};