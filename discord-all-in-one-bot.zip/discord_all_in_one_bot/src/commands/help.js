const {SlashCommandBuilder, EmbedBuilder} = require("discord.js");
module.exports = {data: new SlashCommandBuilder().setName("help").setDescription("Show bot commands"),
async execute(i) {
 const e = new EmbedBuilder().setTitle("🤖 All-in-One Bot").addFields(
  {name:"🛡️ Moderation",value:"`/moderation ban|kick|timeout|warn|clear`"},
  {name:"🎫 Tickets",value:"`/ticket panel`"},
  {name:"💰 Economy",value:"`/economy balance|daily`"},
  {name:"📊 Info",value:"`/info server|user`"},
  {name:"🎵 Music",value:"`/music play|pause|skip|queue`"},
  {name:"🤖 AI",value:"`/ai`"});
 await i.reply({embeds:[e]});
}};